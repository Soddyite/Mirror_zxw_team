package com.example.dllo.mirror.controller.fragment;

import com.example.dllo.mirror.R;

/**
 * Created by zouliangyu on 16/6/15.
 */
public class TopicDetailsFragment extends BaseFragment {
    @Override
    protected int getLayout() {
        return R.layout.activity_topic_details_viewpager;
    }

    public TopicDetailsFragment() {
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
