package com.example.dllo.mirror.model.bean;

/**
 * Created by zouliangyu on 16/6/13.
 */
public class MyData {
    private int image;

    public MyData(int image) {
        this.image = image;
    }

    public MyData() {
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
