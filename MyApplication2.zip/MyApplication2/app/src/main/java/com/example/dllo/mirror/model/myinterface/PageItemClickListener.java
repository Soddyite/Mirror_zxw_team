package com.example.dllo.mirror.model.myinterface;

/**
 * Created by dllo on 16/6/17.
 */
public interface PageItemClickListener {
    void onClick(int Id);
}
